package com.example.SOP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SopApplicationTests {

	@Test
	void contextLoads() {
	}

}
